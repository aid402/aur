
#include "crypto_stream_salsa20.h"

#define crypto_stream crypto_stream_salsa20
#define crypto_stream_xor crypto_stream_salsa20_xor
